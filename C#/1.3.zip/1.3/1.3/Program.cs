﻿using System;
namespace _1._3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var uncheckedResult = GetUnchecked();
            Console.WriteLine($"Unchecked result: {uncheckedResult}\n");

            var checkedResult = GetChecked();
            Console.WriteLine($"Checked result: {checkedResult}\n");

            
        }

        static int GetChecked()
        {
            checked
            {
                int maxInt = int.MaxValue;
                return maxInt + 1;
            }
        }

        static int GetUnchecked()
        {
            unchecked
            {
                int maxInt = int.MaxValue;
                return maxInt + 1;
            }
        }
    }
}